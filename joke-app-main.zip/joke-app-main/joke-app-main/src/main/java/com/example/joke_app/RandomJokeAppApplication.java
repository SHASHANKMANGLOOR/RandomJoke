package com.example.joke_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RandomJokeAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(RandomJokeAppApplication.class, args);
    }
}
