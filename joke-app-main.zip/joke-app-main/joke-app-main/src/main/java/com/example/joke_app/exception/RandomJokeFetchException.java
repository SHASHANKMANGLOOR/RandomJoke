package com.example.joke_app.exception;

public class RandomJokeFetchException extends RuntimeException {
    public RandomJokeFetchException(String message) {
        super(message);
    }
}
