package com.example.joke_app.exception;

public class NoContentException extends RuntimeException {
    public NoContentException(String message) {
        super(message);
    }
}
