package com.example.joke_app.exception;

public class ServiceExcpetion extends RuntimeException {
    public ServiceExcpetion(String message) {
        super(message);
    }
}
